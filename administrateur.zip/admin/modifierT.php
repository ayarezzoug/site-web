

<?php
//connexon à la dd
$objetPdo = new PDO('mysql:host=localhost;dbname=site','root','');
//préparation de la requete
$pdoStat = $objetPdo->prepare('SELECT * FROM types WHERE id_type=:num ');
//liaison du paramètre nommé
$pdoStat->bindvalue(':num', $_GET['numType'], PDO::PARAM_INT);
//exécution de la requete
$executei = $pdoStat->execute();
//ON RECUP7RE LE TYPE
$type = $pdoStat->fetch();

?>

<?php
//connexon à la bdd
$objetPdo = new PDO('mysql:host=localhost;dbname=site','root','');
//préparation de la requete
$pdoStat = $objetPdo->prepare('UPDATE types set nom_type=:nom WHERE id_type = :num LIMIT 1 ');
//liaison du paramètre nommé
$pdoStat->bindvalue(':num', $_POST['idtype'], PDO::PARAM_INT);
$pdoStat->bindvalue(':nom', $_POST['type'], PDO::PARAM_STR);
//exécution de la requete
$executei = $pdoStat->execute();
if ($executei) {
   echo 'le type a été mis à jour';
}
else{
  echo  'Echec';
}
?>









<!DOCTYPE html>
<html>
  <head>
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Modifier un type</title>
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.css" rel="stylesheet">
 

  </head>
<body>
	<form  method="post" action="#">  
<input type="hidden" id="id_type" name="idtype" value="<?=  $type['id_type'] ?>">    
<label>Nom de type :</label><input type="text" id="nom_type" name="type" value="<?=  $type['nom_type'] ?>">
<button class="btn-secondary" name="ajouter">Mettre à jour</button>
</form>


                 <a href="Types.php" type="button" class="btn-secondary btn-lg"  ><i class="fas fa-arrow-left"></i>   Allez vers la liste des types </a>
               
</body>
</html>