<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['myusername'];
   
   $ses_sql = mysqli_query($db,"SELECT username from user where username = '$user_check'");


   while($row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC)){
      echo  $row['username'];
      }
      
   $login_session = $row['username'];
   
   if(!isset($_SESSION['myusername'])){
      header("location: login.php");
      die();
   }
?>