<?php

include("config.php");
if($_SERVER["REQUEST_METHOD"] == "POST") {
$type = mysqli_real_escape_string($db,$_POST['type']);	
$req = "DELETE FROM types WHERE nom_type = '$type'";
$result = mysqli_query($db,$req);
mysqli_close($db);
}
?>