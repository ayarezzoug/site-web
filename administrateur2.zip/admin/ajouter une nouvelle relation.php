<?php
include('config.php');
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") {
// On commence par récupérer les champs
if(isset($_POST['gare_dep']))      $dep=$_POST['gare_dep'];
else      $dep="";
if(isset($_POST['gare_arr']))      $arr=$_POST['gare_arr'];
else      $arr="";
if(isset($_POST['type']))      $type=$_POST['type'];
else      $quai="";
if(isset($_POST['nbr_stations']))      $nbr=$_POST['nbr_stations'];
else      $nbr="";

// On vérifie si les champs sont vides
if(empty($dep))
    {
    echo '<font color="red">Attention, il faut choisir la gare de depart!</font>';
    }
    elseif(empty($arr))
    {
    echo '<font color="red">Attention, il faut choisir la gare darrivé !</font>';
    }
elseif(empty($type))
    {
    echo '<font color="red">Attention, il faut choisir un type !</font>';
    }
    elseif(empty($nbr))
    {
    echo '<font color="red">Attention, il faut saisir le nombre de stations !</font>';
    }
// Aucun champ n'est vide, on peut enregistrer dans la table
else     
    {
  
     // on regarde si l'url existe déjà
    $sql = "SELECT id_relation FROM relations WHERE nom_gare_dep='$dep' AND nom_gare_arr='$arr' AND nom_type='$type' AND nbr_station='$nbr'";
    $req = mysqli_query($db,$sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error($db)); 
    
    // on compte le" nombre de résultats
    $res = mysqli_num_rows($req);

    if($res!=0)  // l'url existe déjà, on affiche un message d'erreur
        {
        echo '<font color="red">Désolé, mais cette relation existe déjà dans notre base.</font>';
        }
    else  // L'url n'existe pas, on insère les informations du formulaire dans la table
        {   
        $sql = "INSERT INTO relations(id_relation, nom_gare_dep, nom_gare_arr, nom_type, nbr_station, id_dec) VALUES(null,'$dep','$arr','$type','$nbr', '$nbr')";
        $req = mysqli_query($db,$sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error($db)); 
        
        // on affiche le résultat pour le visiteur
        echo 'Vos infos on été ajoutées.';

        }

     // on ferme la connexion
    }
     } 

?>


<?php
//connexon à la bdd
$objetPdo = new PDO('mysql:host=localhost;dbname=site','root','');
//préparation de la requete
$pdoStat = $objetPdo->prepare('SELECT nom_type FROM types ORDER BY nom_type ASC');
//exécution de la requete
$executei = $pdoStat->execute();
//recuperer les resultats en une seule fois
$types = $pdoStat->fetchAll();
?>

<?php
//connexon à la bdd
$objetPdo = new PDO('mysql:host=localhost;dbname=site','root','');
//préparation de la requete
$pdoStat = $objetPdo->prepare('SELECT nom_gare FROM gares ORDER BY nom_gare ASC');
//exécution de la requete
$executei = $pdoStat->execute();
//recuperer les resultats en une seule fois
$gares = $pdoStat->fetchAll();
?>




<!DOCTYPE html>
<html lang="en">
  <head>
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Ajouter une nouvelle relation</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.css" rel="stylesheet">


  </head>

<body id="page-top" >
<?php
   include('C:\wamp64\www\admin\navbar.php');
?>
      
<?php
   include('C:\wamp64\www\admin\logout.php');
?>

 

       <h3 class="text-center"><b>AJOUTER UNE NOUVELLE RELATION</b></h3>

        <!-- Begin Page Content -->
        <div class="container">
              <!--formulaire-->
              <form action="#" method="post">

                <!--gare dep-->
                <div class="col-sm-4">
               <label>La gare de départ :</label>
              <select size="1" class="form-control" name="gare_dep">
              <option>Choisir la gare de départ</option>
               <?php foreach ($gares as $gare): ?>
                <option name="gare_dep"><?= $gare['nom_gare'] ?></option>
                <?php endforeach; ?>
              </select> 
               </div>
                <br><br> 

                 <!--gare arrivée-->
                <div class="col-sm-4">
                <label>La gare de l'arrivé :</label>  
                <select size="1" class="form-control" name="gare_arr">
              <option value="">Choisir la gare de l'arrivé</option>
              <?php foreach ($gares as $gare): ?>
                <option name="gare_arr"><?= $gare['nom_gare'] ?></option>
                <?php endforeach; ?>
              </select>
              </div> 
                <br><br> 

             
                <!--type relation-->
               <div class="col-sm-4">
                  <label>Le type de la relation :</label>
                    <select class="form-control" name="type">
                     <option >Sélectionner le type de la relation</option>
                     <?php foreach ($types as $type): ?>
                      <option name="type"><?= $type['nom_type'] ?></option>
                      <?php endforeach; ?>
                     </select>
                  </div> 

                  <br><br>
                  <!--les stations-->
            <div class="col-sm-4">
             <label>Nombre de gares intermmédiares :</label><input type="text" name="nbr_stations">
             </div>
          

          <?php
          $nom = $gare["nom_gare"];
         for ($station = 1; $station <=$nom ; $station++)
         {
          echo 'Ceci est la ligne n°' . $station . '<br />';
         }
         ?>







             <div id="div4">
                 <button class="btn btn-secondary btn-lg">Enregistrer</button>
              </div>
              </form>
          </div>     
    

            






  <script src="js/jquery-5.3.1.js"></script>  
  <script src="vendor/jquery/jquery.js"></script>
  <script src="js/sb-admin-2.js"></script>
 <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>



               

</body>
</html>