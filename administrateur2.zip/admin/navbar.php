
  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-secondary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <button> <img src=""></button>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - ACCUEIL -->
      <li class="nav-item active">
        <a  href="index.php" class="nav-link">
          <i class="fas fa-home"></i>Accueil</a>
    </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      
      <!-- Nav Item - la liste des gares -->
      
      <li class="nav-item active">    
        <a href="la liste des gares.php" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>La liste des gares</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

    <!-- Nav Item - la liste des relations -->
      
      <li class="nav-item active">    
        <a href="la liste des relations.php" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>La liste des relations</span></a>
      </li>
      <hr class="sidebar-divider"> 
      
      <!-- Nav Item - la liste des des trains  -->
      
      <li class="nav-item active">    
        <a href="la liste des trains.php" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>La liste des trains</span></a>
      </li>
      <hr class="sidebar-divider"> 

       <!-- Nav Item - Marches -->
    <li class="nav-item active">    
        <a href="Marches.php" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>Programmation des marches</span></a>
      </li>
      <hr class="sidebar-divider"> 

      <!-- Nav Item - Types  -->
      
      <li class="nav-item active">    
        <a href="Types.php" class="nav-link">
          <i class="fas fa-caret-square-down"></i>
          <span>types</span></a>
      </li>

       <hr class="sidebar-divider"> 
      <li class="nav-item active">    
        <a href="mode de circulation.php" class="nav-link">
          <i class="fas fa-caret-square-down"></i>
          <span>Modes de circulation</span></a>
      </li>
      
      
      <br>

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-lignt bg-secondary topbar mb-4 static-top shadow">
          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
             <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
          
            <div class="topbar-divider d-none d-sm-block"></div>
            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-blue-600 small">USER</span>
                <i class="fas fa-user"></i>
              </a>
            
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Déconnecté
                </a>
              </div>
            </li>

          </ul>

        </nav>

        <!-- End of Topbar -->