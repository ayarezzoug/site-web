<?php
include('config.php');
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") {
// On commence par récupérer les champs
if(isset($_POST['type']))      $type=$_POST['type'];
else      $type="";


// On vérifie si les champs sont vides
if(empty($type))
    {
    echo '<font color="red">Attention, il faut remplir le champ !</font>';
    }

// Aucun champ n'est vide, on peut enregistrer dans la table
else     
    {
  
     // on regarde si l'url existe déjà
    $sql = "SELECT id_type FROM types WHERE nom_type='$type'";
    $req = mysqli_query($db,$sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error($db)); 
    
    // on compte le nombre de résultats
    $res = mysqli_num_rows($req);

    if($res!=0)  // l'url existe déjà, on affiche un message d'erreur
        {
        echo '<font color="red">Désolé, mais ce TYPE existe déjà dans notre base.</font>';
        }
    else  // L'url n'existe pas, on insère les informations du formulaire dans la table
        {   
        $sql = "INSERT INTO types(id_type, nom_type) VALUES(null,'$type')";
        $req = mysqli_query($db,$sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error($db)); 
        
        // on affiche le résultat pour le visiteur
        echo 'Vos infos on été ajoutées.';

        }

     // on ferme la connexion
    }
     } 

?>


<!--lister les types-->
<?php
//connexon à la bdd
$objetPdo = new PDO('mysql:host=localhost;dbname=site','root','');
//préparation de la requete

$pdoStat = $objetPdo->prepare('SELECT * FROM types ORDER BY nom_type ASC');
//exécution de la requete
$executei = $pdoStat->execute();
//recuperer les resultats en une seule fois
$types = $pdoStat->fetchAll();
?>








<!DOCTYPE html>
<html lang="en">
  <head>
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Types (gares/relations)</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.css" rel="stylesheet">
  <script>
function rtn() {
   window.history.back();
}
</script>

  </head>

<body id="page-top" >

    <?php
   include('C:\wamp64\www\admin\navbar.php');
?>
            
    <?php
   include('C:\wamp64\www\admin\logout.php');
?>
<h3>Types (gares/relations)</h3>
        <!-- End of Topbar -->
        <div class="container">
          
         <br><br> 
 <form  method="post" action="#">  
      
<label>Nom de type :</label><input type="text" id="nom_type" name="type" >
<button class="btn-secondary">Ajouter</button>
</form>
<hr>
 
<h3> La liste des types :</h3>

<ul>
  <?php foreach ($types as $type): ?>

<li>
  <?= $type['nom_type']  ?>
 <a href="modifierT.php?numType= <?= $type['id_type'] ?>" class = "btn-secondary">Modifier</a>

</li>

<?php endforeach; ?>

</ul>
   



               <!--le bas de la page-->       
              
               <div id="div3">
                 <button class="btn-secondary btn-lg" onclick="rtn()"><i class="fas fa-arrow-left"></i>   page précédente</button>
               </div>
</div>

        <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>



               

</body>
</html>