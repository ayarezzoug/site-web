<?php
include('config.php');
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") {
// On commence par récupérer les champs
if(isset($_POST['nom']))      $nom=$_POST['nom'];
else      $nom="";
if(isset($_POST['voie']))      $voie=$_POST['voie'];
else      $voie="";
if(isset($_POST['quai']))      $quai=$_POST['quai'];
else      $quai="";
if(isset($_POST['type']))      $type=$_POST['type'];
else      $type="";

// On vérifie si les champs sont vides
if(empty($nom))
    {
    echo '<font color="red">Attention, il faut remplir le nom de la gare!</font>';
    }
    elseif(empty($voie))
    {
    echo '<font color="red">Attention, il faut remplir le nombre de voies !</font>';
    }
elseif(empty($quai))
    {
    echo '<font color="red">Attention, il faut remplir le nombre de quais !</font>';
    }
    elseif(empty($type))
    {
    echo '<font color="red">Attention, il faut choisir un type !</font>';
    }
// Aucun champ n'est vide, on peut enregistrer dans la table
else     
    {
  
     // on regarde si l'url existe déjà
    $sql = "SELECT id_gare FROM gares WHERE nom_gare='$nom' AND nbr_voies='$voie' AND nbr_quis='$quai' AND nom_type='$type'";
    $req = mysqli_query($db,$sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error($db)); 
    
    // on compte le nombre de résultats
    $res = mysqli_num_rows($req);

    if($res!=0)  // l'url existe déjà, on affiche un message d'erreur
        {
        echo '<font color="red">Désolé, mais cette gare existe déjà dans notre base.</font>';
        }
    else  // L'url n'existe pas, on insère les informations du formulaire dans la table
        {   
        $sql = "INSERT INTO gares(id_gare, nom_gare, nbr_voies, nbr_quis, nom_type) VALUES(null,'$nom','$voie','$quai','$type')";
        $req = mysqli_query($db,$sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error($db)); 
        
        // on affiche le résultat pour le visiteur
        echo 'Vos infos on été ajoutées.';

        }

     // on ferme la connexion
    }
     } 

?>


<?php
//connexon à la bdd
$objetPdo = new PDO('mysql:host=localhost;dbname=site','root','');
//préparation de la requete

$pdoStat = $objetPdo->prepare('SELECT nom_type FROM types ORDER BY nom_type ASC');
//exécution de la requete
$executei = $pdoStat->execute();
//recuperer les resultats en une seule fois
$types = $pdoStat->fetchAll();
?>







<!DOCTYPE html>
<html lang="en">
  <head>
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Ajouter une nouvelle gare</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script>
function rtn() {
   window.history.back();
}
</script>

  </head>

<body id="page-top" >

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-secondary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <button> <img src=""></button>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - ACCUEIL -->
      <li class="nav-item active">
        <a  href="index.php" class="nav-link">
          <i class="fas fa-home"></i>Accueil</a>
    </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      
      <!-- Nav Item - la liste des gares -->
      
      <li class="nav-item active">    
        <a href="la liste des gares.php" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>La liste des gares</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

    <!-- Nav Item - la liste des relations -->
      
      <li class="nav-item active">    
        <a href="la liste des relations.php" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>La liste des relations</span></a>
      </li>
      <hr class="sidebar-divider"> 
      
      <!-- Nav Item - la liste des des trains  -->
      
      <li class="nav-item active">    
        <a href="la liste des trains.html" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>La liste des trains</span></a>
      </li>
      <hr class="sidebar-divider"> 

       <!-- Nav Item - Marches -->
     <li class="nav-item active">    
        <a href="Marches.html" class="nav-link">
          <i class="fas fa-list-ul"></i>
          <span>Programmation des marches</span></a>
      </li>
      <hr class="sidebar-divider"> 

      <!-- Nav Item - Types  -->
      
      <li class="nav-item active">    
        <a href="Types.php" class="nav-link">
          <i class="fas fa-caret-square-down"></i>
          <span>types</span></a>
      </li>
      
      <br>

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-lignt bg-secondary topbar mb-4 static-top shadow">
            
          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
             <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
          
            <div class="topbar-divider d-none d-sm-block"></div>
            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-blue-600 small">USER</span>
                <i class="fas fa-user"></i>
              </a>
            
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="login.html" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Déconnecté
                </a>
              </div>
            </li>

          </ul>

        </nav>

        <!-- End of Topbar -->
      




        <h3 class="text-center">AJOUTER UNE NOUVELLE GARE</h3>

        <!-- Begin Page Content -->
        <div class="container">
             
             
            <br><br>
              <!--formulaire-->
                <form action="#" method="post">
                <!--nom gare-->
                  <div class="col-sm-4">
                  <label>Nom de gare :</label>  <input type="text" class="form-control" id="Nom_gare" placeholder="saisir le nom de la gare" name="nom">
                  </div>

                  <br>
                  <!--nbr voies-->
                  <div class="col-sm-4">
                      <label>Nombre de voies :</label>  <input type="text" class="form-control" id="nbr_voies" placeholder="saisir le nombre de voies" name="voie">
                  </div>

                  <br>
                 <!--nbr quais-->
                <div class="col-sm-4">
                    <label>Nombre de quais :</label> <input type="text" class="form-control" id="nbr_quais" placeholder="saisir le nombre de quais" name="quai">
                  </div>

                     <!--type de la gare-->
                <div class="col-sm-4">
                	<label>Le type de la gare :</label>
                    <select class="form-control" name="type">
                     <option >Sélectionner le type de la gare</option>
                     <?php foreach ($types as $type): ?>
                     	<option name="type"><?= $type['nom_type'] ?></option>
                     	<?php endforeach; ?>
                     </select>
                  </div><br><br><br><br><br><br>

            
         
               <!--le bas de la page-->    
                <div id="div4">
                 <button class="btn-secondary btn-lg">Enregistrer</button>
               </div>   

               <div id="div3">
                 <button class="btn-secondary btn-lg" onclick="rtn()"><i class="fas fa-arrow-left"></i>   page précédente</button>
               </div>

              </form>
               

            


           </div>

<!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Prêt à partir?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Sélectionnez «Déconnexion» ci-dessous si vous êtes prêt à mettre fin à votre session en cours.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Annuler</button>
          <a class="btn btn-primary" href="login.html">Déconnecté</a>
        </div>
      </div>
    </div>
  </div>

 <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/bootstrap.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>



               

</body>
</html>