
<?php
//connexon à la dd
$db = new PDO('mysql:host=localhost;dbname=site','root','');
$id =$_GET["numtrain"];
if(isset($_GET["numtrain"]))
        {
            $id_train = $_GET["numtrain"];
            if(!empty($id))
            {
$oo = $db->prepare("SELECT * FROM trains WHERE id_train= $id");
        $oo->execute();
        $train = $oo->fetch();
        $num = $train["num_train"];
        $type = $train["type_train"];
        
      
            }
            }

if(isset($_POST["modifier"]))
{
    $num = $_POST['num'];
    $type = $_POST['type'];
    

    //$id_user = $_POST["id_user"];
    if(!empty($num) && !empty($type) )
    {
        $n="UPDATE trains SET num_train='$num' WHERE id_train=$id_train LIMIT 1";
        $t="UPDATE trains SET type_train='$type' WHERE id_train=$id_train LIMIT 1";
    
        $db->exec($n);
        $db->exec($t);
       
     }
     }
      ?>

     <?php
$db = new PDO('mysql:host=localhost;dbname=site','root','');
     if(isset($_GET["numtrain"])){
    $id = $_GET["numtrain"];
    if(!empty($id))
    {
        $query = "DELETE FROM trains WHERE id_train=$id";
        $db->exec($query);
      }
       }

        ?>





        <!DOCTYPE html>
<html lang="en">
  <head>
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Modifier la gare</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.css" rel="stylesheet">

    <script>
function rtn() {
   window.history.back();
}
</script>



  </head>

<body id="page-top" >

   <?php
   include('C:\wamp64\www\admin\navbar.php');
?>
            
    <?php
   include('C:\wamp64\www\admin\logout.php');
?>
      

<h3 class="text-center"><b>MODIFIER UN TRAIN</b></h3>
<div class="container">
  <form action="#" method="post">
  <input type="hidden" id="id_train" name="idgare" value="<?=  $train['id_train'] ?>"> 
  <label>Numéro du train :</label> <input type="text" class="form-control" placeholder="saisir le numéro de train" name="num" value="<?=  $train['num_train'] ?>">
  <br><br/>
  <label>Le type de train :</label> 
   <select size="1" name="type" class="form-control" value="<?=  $train['type_train'] ?>">
      <option name="type"><?=  $train['type_train'] ?></option>
      <option>rapide</option>
       </select>

     <!--le bas de la page-->       
   <div id="div4">
                 <button class="btn btn-secondary btn-lg" name="supprimer">Supprimer</button>
                 <button class="btn btn-secondary btn-lg" name="modifier">Mettre à jour</button>
               </div>

    <div id="div3">
    <button class="btn-secondary btn-lg" onclick="rtn()"><i class="fas fa-arrow-left"></i>   page précédente</button>
   </div>

  </form>

 </div>

              




  
 <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>



               

</body>
</html>